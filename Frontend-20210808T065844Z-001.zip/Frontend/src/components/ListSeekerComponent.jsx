import React, { Component } from 'react'
//import DonorService from '../services/DonorService'
import PersonService from '../services/PersonService';
import SeekerService from '../services/SeekerService';
import { NavLink } from 'react-router-dom';
import undertaking from '../images/UNDERTAKING.pdf';

export default class ListSeekerComponent extends Component {


	constructor(props) {
		super(props)
		this.state = this.initialState;
		this.createSeeker = this.createSeeker.bind(this);
		this.editUser = this.editUser.bind(this);
		this.logout = this.logout.bind(this);
		this.getDonorsForSeekerByBloodGroup = this.getDonorsForSeekerByBloodGroup.bind(this);
		this.requestsMade = this.requestsMade.bind(this);
		this.showDonorDetails = this.showDonorDetails.bind(this);
		this.cancelRequest = this.cancelRequest.bind(this);
	}

	initialState = {
		donors: [],
		seeker: []
	}




	componentDidMount() {

		// console.log("hello",window.localStorage.getItem("emailId"));
		SeekerService.getSeeker(window.localStorage.getItem("emailId")).then((res) => {
			// console.log(res.data.result);
			this.setState({ seeker: res.data.result });
			// console.log(window.localStorage.getItem("emailId"));
			// console.log(this.state.donor);
		});
		this.requestsMade();

	}

	requestsMade() {
		SeekerService.seekerGetAllRequestedDonors(window.localStorage.getItem("emailId"))
			.then((res) => {
				// console.log(res);
				// console.log(res.data.result);
				this.setState({ donors: res.data.result });
				// if(this.state.donor.requestStatus.length===0){
				// 	console.log("empty");
				// }
				// console.log(this.state.donors.requestStatus);
			});
	}

	createSeeker() {
		this.props.history.push('/seeker_registration');
	}

	editUser() {
		if (window.localStorage.getItem("role") === "DONOR") {
			this.props.history.push('/edit_donor');
		}
		if (window.localStorage.getItem("role") === "SEEKER") {
			this.props.history.push('/edit_seeker');
		}
	}
	logout() {
		alert("Goodbye, " + this.state.seeker.firstName)
		window.localStorage.removeItem("emailId");
		// console.log(this.setState(this.initialState));
		this.props.history.push('/');
	}

	deleteUser() {
		// window.localStorage.removeItem("emailId");
		// console.log(this.setState(this.initialState));
		PersonService.deletePersonDetails(window.localStorage.getItem("emailId")).then(
			res => {
				alert("We feel sad to see you go.")
				window.localStorage.removeItem("emailId");
				// console.log(this.setState(this.initialState));
				this.props.history.push('/');
			}
		)

	}
	getDonorsForSeekerByBloodGroup() {
		this.props.history.push("/search");
	}


	showDonorDetails(requestStatus, donorEmail) {
		if (requestStatus === 1) {
			// console.log("request not accepted yet");
		}
		if (requestStatus === 2) {
			window.localStorage.setItem("donorEmail", donorEmail);
			this.props.history.push("/donor_details");
		}
		if (requestStatus === 3) {
			// console.log("request Rejected");
		}

	}

	cancelRequest(donorEmail){
		console.log("hello here",window.localStorage.getItem("emailId"))
		SeekerService.cancelRequest(window.localStorage.getItem("emailId"), donorEmail).then(res =>{
			alert("RequestCancelled");
			this.componentDidMount()
		})
		
	}

	render() {
		return (
			<div>
				{/* Banner */}
				<section id="banner">
					<h1 className="text-center" style={{ textTransform: 'uppercase', fontWeight: 525 }}>Hello, {this.state.seeker.firstName}</h1>
					<p style={{ fontSize: 'x-large', fontWeight: 325 }}>Donate, Find Convalescent Plasma Across The Nation</p>
				</section>

				<div >
					<header>
						<br />
						<br />
						<h2 style={{ fontWeight: 'bold', textAlign: 'center' }}>{this.state.seeker.firstName} {this.state.seeker.lastName}, {this.state.seeker.age}
							({this.state.seeker.bloodGroup}) <br /></h2>
					</header>
				</div>
				<br />
				<table className="table table-stripped table-bordered">
					<thead>
						<tr>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Phone Number</th>
							<th>Age</th>
							<th>Email ID</th>
							{/* <th>Password</th> */}
							<th>State Name</th>
							<th>Blood Group</th>
							<th>Last Test Date</th>
						</tr>
					</thead>
					<tbody>
						{
							// this.state.map(
							// 	donor =>
							<tr >
								<td> {this.state.seeker.firstName} </td>
								<td> {this.state.seeker.lastName} </td>
								<td> {this.state.seeker.phoneNumber} </td>
								<td> {this.state.seeker.age} </td>
								<td> {this.state.seeker.email} </td>
								{/* <td> {this.state.donor.password} </td> */}
								<td> {this.state.seeker.stateName} </td>
								<td> {this.state.seeker.bloodGroup} </td>
								<td> {this.state.seeker.lastSymptomDate}</td>
								{/* {console.log(this.state.seeker.lastSymptomDate)} */}
							</tr>
							// )
						}
					</tbody>
				</table>
				<br />
				<div style={{ textAlign: 'center' }}>
					<button style={{ backgroundColor: '#7acdf1' }} onClick={this.logout}>Logout</button>{' '}
					<button style={{ backgroundColor: '#7acdf1' }} onClick={this.editUser}>Edit Details</button>{' '}
					{/* <button style={{ backgroundColor: '#7acdf1' }} onClick={this.addDonor}>Add Donor</button>{' '} */}
					<button style={{ backgroundColor: '#E14141' }} onClick={() => { if (window.confirm('Delete the item?')) { this.deleteUser() }; }}>Delete Profile</button>
					<button style={{ backgroundColor: '#7acdf1' }} onClick={this.getDonorsForSeekerByBloodGroup}>Search</button>

				</div>

				<br />
				<div>
					<h2 style={{ fontWeight: 'bold', textAlign: 'center' }}>Requests Made</h2>
					<div>
						<table>
							<thead>
								<tr>
									<th>First Name</th>
									<th>Last Name</th>
									<th>Age</th>
									{/* <th>Password</th>  */}
									<th>State Name</th>
									<th>Blood Group</th>
									<th>Last Test Date</th>
									<th>Request Status</th>
								</tr>
							</thead>
							<tbody>
								{
									this.state.donors.map(
										donor =>
											<tr key={donor.donorId}>
												{console.log(donor)}

												<td> {donor.firstName} </td>
												<td> {donor.lastName} </td>
												<td> {donor.age} </td>
												<td> {donor.stateName} </td>
												<td> {donor.bloodGroup} </td>
												<td> {donor.testDate} </td>
												{donor.requestStatus === 1? <td>Pending</td>: null}
												{donor.requestStatus === 2? <td>Accepted</td>: null}
												{donor.requestStatus === 3? <td>Rejected</td>: null}
												
												{/* <td> {donor.requestStatus} </td> */}
												{donor.requestStatus=== 2 ? <td><button style={{ backgroundColor: '#7acdf1' }} onClick={(e) => this.showDonorDetails(donor.requestStatus, donor.email)}>Show Details</button></td> : null}
												{donor.requestStatus=== 1 ? <td><button style={{ backgroundColor: '#7acdf1' }} onClick={(e) => this.cancelRequest(donor.email)}>cancelRequest</button></td> : null}
											</tr>
									)
								}
							</tbody>
						</table>
					</div>
				</div>
				<br />
				<p style={{ textAlign: 'center' }}>Users MUST read and duly sign the completely filled  <NavLink to={undertaking} target="_blank">undertaking form</NavLink> at the time donors report at plasma receiver's
					location; BEFORE undergoing the transfusion process.</p>


			</div>

		)
	}
}
