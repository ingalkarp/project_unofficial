import React from 'react';
import {Link} from 'react-router-dom';
import homeimg from '../images/home-img.jpg';
// import aishwarya from '../images/img02.jpg';
// import prabuddha from '../images/img01.jpg';
// import samadhan from '../images/img03.jfif';
import MoreThingsToKnow from './MoreThingsToKnow';


const Home = () => {
    return (
        <div>
            {/* Banner */}
            <section id="banner">
                <h1 style={{fontWeight: 525}}>LifeLine<sup>©</sup> Community Blood Bank</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Donate, Find Blood Across The Nation</p>
            </section>

            {/* One */}
            <section id="one" className="wrapper">
        <div className="inner">
          <div className="flex flex-3">
            <article>
              <header>
                <h3 style={{fontWeight: 'bold'}}>Find Blood<br /></h3>
              </header>
              <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Create a free account, and find available, eligible blood donors near you.</p><br />
              {/* <footer> */}
                <Link to= '/seeker_registration' className="hvr-rectangle-out special">
                  Register Now
                </Link>
                
              {/* </footer> */}
            </article>
            <article>
              <header>
                <h3 style={{fontWeight: 'bold'}}>Donate Blood<br /></h3>
              </header>
              <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Register as a blood donor, people looking for blood can then find you, and request to contact you.</p>
              <footer>
                <Link to="/donor_registration" className="hvr-rectangle-out special">Register Now</Link>
              </footer>
            </article>
            <article>
              <header>
                <h3 style={{fontWeight: 'bold'}}>How Does It Work ?<br /></h3>
              </header>
              <p style={{fontWeight: 'bold', textAlign: 'justify'}}>See how <i>Lifeline Community Blood Bank</i> platform works and make the best use of it.</p><br />
              <footer>
                <Link to="/faq" className="hvr-rectangle-out special">Learn More</Link>
              </footer>
            </article>
          </div>
        </div>
      </section>


        {/* Two */}
        {/* <section id="two" className="wrapper style1 special">
        <div className="inner">
          <header>
            <h2 style={{fontWeight: 'bold'}}>Testimonials</h2>
            <p style={{fontSize: 'large'}}>Take a look at people's experiences of using this platform, and the overall process. </p>
          </header>
          <div className="flex flex-4">
            <div className="box person">
              <div className="image round">
                <img src={pritam} alt="Person 1" />
              </div>
              <h3>Pritam Ingalkar</h3>
              <p>Donated blood at Nagpur, MH</p>
            </div>
            <div className="box person">
              <div className="image round">
                <img src={aishwarya} alt="Person 2" />
              </div>
              <h3>Aishwarya Ingle</h3>
              <p>Donated blood at Malkapur, MH</p>
            </div>
            <div className="box person">
              <div className="image round">
                <img src={prabuddha} alt="Person 3" />
              </div>
              <h3>Prabuddha Salve</h3>
              <p>Found a donor at Maharashtra</p>
            </div>
            <div className="box person">
              <div className="image round">
                <img src={samadhan} alt="Person 4" />
              </div>
              <h3>Samadhan Sawant</h3>
              <p>Donated blood at Maharashtra</p>
            </div>
          </div>
        </div>
      </section> */}
      <section id="two" className="wrapper style1 special">
        <div className="inner">       
           <img src={homeimg} style={{width:'900px'}}/>
   
        </div>
      </section>
      <MoreThingsToKnow />
        
        </div>


    );
};

export default Home;