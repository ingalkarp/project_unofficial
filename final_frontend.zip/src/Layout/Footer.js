import React from 'react';
import { Link, NavLink } from 'react-router-dom';

const Footer = () => {
    return (
        <div>
            <footer id="footer">
                <div className="inner">
                <div className="flex ">
                         <NavLink to='/termsnconditions' target="_blank" className="hvr-wobble-top" style={{color:'#fff'}}>Terms of Service</NavLink>
                        <NavLink to='/privacy_policy' target="_blank" className="hvr-wobble-top" style={{color:'#fff'}}>Privacy Policy</NavLink>
                        <NavLink to='/contact_us' target="_blank" className="hvr-wobble-top" style={{color:'#fff'}}>Contact Us</NavLink>
                        <NavLink to='/feedback' target="_blank" className="hvr-wobble-top" style={{color:'#fff'}}>Feedback</NavLink>
                        <NavLink to='/guidelines' target="_blank" className="hvr-wobble-top" style={{color:'#fff'}}>General Guidelines</NavLink>
                </div><br/>
                <div className="row flex">
                    <ul className="icons">
                    <li><Link to="/" className="icon fa-facebook"><span className="label">Facebook</span></Link></li>
                    <li><Link to="/" className="icon fa-twitter"><span className="label">Twitter</span></Link></li>
                    <li><Link to="/" className="icon fa-instagram"><span className="label">Instagram</span></Link></li>
                    </ul>
                </div>
                
                 <div className="copyright ">
                    © Lifeline Community Blood Bank .
                    </div><br/>                               
                      
               
             
             
                </div>
            </footer>
        </div>
    );
};

export default Footer;