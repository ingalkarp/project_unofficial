import React from 'react';
import '../App.css';

const about_us = () => {
    return (
        <div>
            {/* Banner */}
            <section id="banner">
                <h1 style={{fontWeight: 525}}>About Us</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Our sole mission is to help connect the Blood seekers with Blood Donors...and save lives</p>
            </section>

            {/* Section */}
             <section>
                <div className="inner"><br /><br />
                <p style={{fontSize: 'large', textAlign: 'justify'}}>&nbsp;&nbsp;&nbsp;&nbsp;A well organised Blood Transfusion Service is a vital component of any health care delivery system. An integrated strategy for Blood Safety is required for elimination of transfusion transmitted infections and for provision of safe and adequate blood transfusion services to the people.The main component of an integrated strategy include collection of blood only from voluntary, non-remunerated blood donors, screening for all transfusion transmitted infections and reduction of unnecessary transfusion..</p>
                <p style={{fontSize: 'large', textAlign: 'justify'}}>&nbsp;&nbsp;&nbsp;&nbsp;The main issue, which plagues blood banking system in the country, is fragmented management. The standards vary from state to state, cities to cities and centre to centre in the same city. In spite of hospital based system, many large hospitals and nursing homes do not have their own blood banks and this has led to proliferation of stand-alone private blood banks.Hence, a centralized platform is needed, to connect blood seekers with willing donors directly,LifeLine web app aims to do exactly that.</p>
                <p style={{fontSize: 'large', textAlign: 'justify'}}>&nbsp;&nbsp;&nbsp;&nbsp;This web-based platform that lets both blood seekers and willing blood donors register themselves onto the platform. Then, according to a specific set of rules, creates a list of donor-seeker pairs. An Administrator can then verify the possible pairs, approve the pairs and help make further arrangements for the transfusion, including legal paperwork, coordination with the hospitals/ healthcare organizations, and the users.</p>
                </div>
            </section>
        </div>
    );
};

export default about_us;