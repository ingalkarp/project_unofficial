import React from 'react';
import { Link } from 'react-router-dom';
//mport Form from '../components/Form';
import Logins from '../components/Login';

const Login = () => {
    return (
        <div>
            {/* Banner */}
            <section id="banner">
                {/* <h1 style={{fontWeight: 525}}>Log In</h1> */}

				<div className="flex flex-1">
					<Logins />
				 </div>
            </section>

            {/* Section */}
            <section id="one" className="wrapper">
                <div className="inner">
                <div className="flex flex-2">
                    <article>
                    <header>
                        <h3 style={{fontWeight: 'bold'}}>Register as a Blood Seeker<br /></h3>
                    </header>
                    <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Create a free account, and find available, eligible blood donors near you.</p><br />
                    <footer>
                        <Link to="/seeker_registration" className="hvr-rectangle-out special ">Register Now</Link>
                    </footer>
                    </article>
                    <article>
                    <header>
                        <h3 style={{fontWeight: 'bold'}}>Register as a Blood Donor<br /></h3>
                    </header>
                    <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Register as a Blood donor, people looking for blood can then find you, and request to contact you.</p>
                    <footer>
                        <Link to="donor_registration" className="hvr-rectangle-out special ">Register Now</Link>
                    </footer>
                    </article>
                </div>
                </div>
            </section>
        </div>
    );
};

export default Login;