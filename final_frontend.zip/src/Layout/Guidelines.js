import React from 'react';






const Guidelines = () => {
    return (
        <div>
            {/* Banner */}
            <section id="banner">
                <h1 style={{fontWeight: 525}}>General Guidelines</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Donate, Find Blood Across The Nation</p>
            </section>

            
{/* Three */}
<section>
  <div className="inner"><br /><br />
    <h1 style={{fontSize: 'x-large', fontWeight: 'bold', textAlign: 'center'}}>Who can donate blood</h1>

    <p style={{fontSize: 'medium', textAlign: 'justify'}}><b>Anyone can donate blood if they are in good health. There are some basic requirements one  need to fulfill in order to donate blood. Below are some basic eligibility guidelines: </b> </p>
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Age:</b><br />
    Donor should be aged 18 years and above .<br />
    </p>
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Weight:</b><br />
    The Donor Should not be less than 45 Kilograms.<br />
      <br />
    </p>
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Pulse:</b><br />
    Temperature and Pulse of the donor shall be normal<br />
    </p>
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Child Birth:</b><br />
    Should have delivered 1 year ago and stopped lactation.
    <br />
    </p>
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Blood Pressure:</b><br />
      The systolic and diastolic blood pressures are within normal limits  </p>
      
    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Haemoglobin:</b><br />
    Haemoglobin should not be less than 12.5 grams.</p>	

    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Malaria:</b><br />
    Should Not have been treated for malaria in last 3 months or 3 years if residing in endemic areas</p>	

    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Scars/Skin Puncture:</b><br />
    Arms & Forearms should be free from Skin punctures or Scars which are indicative of Intravenous drug use or frequent blood donations.
    </p>

    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Tattoo/Acupunture:</b><br />
    Should NOT have had any in last 12 months . </p>

    <p style={{fontSize: 'medium', textAlign: 'left'}}><b>Important Info:</b><br />
    Confirmation of your eligibility to donate blood is done by professionals attached
    with Blood banks. If you find you are eligible to donate based on the information displayed here, we encourage you to register as a donor and fix an appointment with hospital nearest to you to donate
    Blood. </p>

      
    
  
  </div>
  
</section>
        </div>
    );
};

export default Guidelines;