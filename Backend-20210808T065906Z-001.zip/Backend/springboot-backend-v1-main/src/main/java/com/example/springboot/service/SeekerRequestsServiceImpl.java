package com.example.springboot.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.model.SeekerRequests;
import com.example.springboot.repository.SeekerRequestsRepository;

@Service
@Transactional
public class SeekerRequestsServiceImpl implements ISeekerRequestsService {
	
	@Autowired
	private SeekerRequestsRepository seekerRequestsRepository;

	@Override
	public SeekerRequests requestStatusBySeekerEmailAndDonorEmail(String seekerEmailId, String donorEmailId) {

//		SeekerRequests s = seekerRequestsRepository.findBySeekerEmailAndDonorEmail(seekerEmailId, donorEmailId);
//		System.out.println(s);
//		return seekerRequestsRepository.findBySeekerEmailAndDonorEmail(seekerEmailId, donorEmailId);
	return null;
	}

	@Override
	public void cancelRequest(String seekerEmail, String donorEmail) {
		seekerRequestsRepository.deleteBySeekerEmailAndDonorEmail(seekerEmail, donorEmail);
		
	}
	
}
