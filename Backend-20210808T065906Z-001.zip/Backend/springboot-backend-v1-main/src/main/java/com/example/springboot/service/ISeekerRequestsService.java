package com.example.springboot.service;

import com.example.springboot.model.SeekerRequests;

public interface ISeekerRequestsService {
	

	SeekerRequests requestStatusBySeekerEmailAndDonorEmail(String seekerEmailId, String donorEmailId);
	void cancelRequest(String seekerEmail, String donorEmail);
}
