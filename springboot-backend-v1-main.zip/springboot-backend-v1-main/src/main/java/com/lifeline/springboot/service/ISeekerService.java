package com.lifeline.springboot.service;

import java.util.List;

import com.lifeline.springboot.dto.DonorDTO;
import com.lifeline.springboot.dto.DonorDetailsAfterMatchingDTO;
import com.lifeline.springboot.dto.DonorDetailsBeforeMatchingDTO;
import com.lifeline.springboot.dto.SeekerDTO;
import com.lifeline.springboot.dto.SeekerRequestsDTO;

public interface ISeekerService {
	
	List<DonorDetailsBeforeMatchingDTO> seekerGetAllDonors(String emailId);
	List<DonorDTO> getAllDonorsByBloodGroup(String bloodGroup);
	List<DonorDTO> getAllDonorsByStateName(String stateName);
	List<DonorDTO> getAllDonorsByBloodGroupAndStateName(String bloodGroup, String stateName);
	String deleteSeekerDetails(String emailId);
	SeekerDTO getSeekerDetails(String emailId);
	Boolean updateSeekerDetails(SeekerDTO donor);
	DonorDetailsAfterMatchingDTO donorInfoAfterAcceptance(String donorEmail);
	
	List<DonorDTO> seekerGetAllDonorsWithRequestStatus(String emailId);
	
	List<DonorDetailsBeforeMatchingDTO>seekerGetAllRequestedDonors(String emailId);
//	void seekerSendRequestToDonor(String seekerEmail, String donorEmail);
}
