package com.lifeline.springboot.service;

import java.util.List;

import com.lifeline.springboot.dto.DonorDTO;
import com.lifeline.springboot.dto.SeekerDTO;

public interface IAdminService {
	List<DonorDTO> getAllDonors();
	String deleteUserDetails(String emailId);
	
	List<SeekerDTO> getAllSeekers();
	String deleteSeekerDetail(String emailId);
}
