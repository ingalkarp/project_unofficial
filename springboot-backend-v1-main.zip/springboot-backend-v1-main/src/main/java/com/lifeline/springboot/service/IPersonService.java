package com.lifeline.springboot.service;

import java.util.List;

import com.lifeline.springboot.dto.PersonDTO;
import com.lifeline.springboot.model.Person;

public interface IPersonService {
	
	List<PersonDTO> getAllPersons();
	PersonDTO addPersonDetails(Person person);
	PersonDTO searchByEmailId(String emailId);
	Boolean deletePersonDetails(String emailId);
	PersonDTO getPersonDetails(int personId);
	PersonDTO updatePersonDetails(int personId,Person person);
	String validatePerson(String emailId, String password);
	
	
	
}
