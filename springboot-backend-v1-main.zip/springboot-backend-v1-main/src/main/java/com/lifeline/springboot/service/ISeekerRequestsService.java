package com.lifeline.springboot.service;

import com.lifeline.springboot.model.SeekerRequests;

public interface ISeekerRequestsService {
	

	SeekerRequests requestStatusBySeekerEmailAndDonorEmail(String seekerEmailId, String donorEmailId);
	void cancelRequest(String seekerEmail, String donorEmail);
}
