import React from 'react';
import {NavLink} from 'react-router-dom';
import three from '../images/hiw16.png';
import four from '../images/hiw04.png';
import undertaking from '../images/UNDERTAKING.pdf';

const MoreThingsToKnow = () => {
    return (
        <div>

<section id="three" className="wrapper special">
  <div className="inner">
    <header className="align-center">
      <h2 className="sub-head" style={{fontWeight: 'bold'}}>Important Things To Know</h2>
    </header>
    <div className="flex flex-2">
            <article>
                    <div className="image fit">
                        <img src={three} alt="Official Guidelines" style={{width: '100px', height: '80px', display: 'block', margin:'auto'}} />
                    </div>
                    <header>
                        <h3 style={{fontWeight: 'bold', textAlign: 'center'}}>Official Guidelines</h3>
                    </header>
                    <p style={{fontWeight: 'bold',  textAlign:"center"}}>The Mistry of Health and Family Welfare of India has issued a circular, defining a set of guidlines to be followed in a CPT therapy. Read this before your visit to the donation center.</p>
                    <footer>
                        <div className="align-center">
                    <NavLink 
                    to={{ pathname: "#"}} 
                    className="button special" target="_blank" >Learn More</NavLink>
                    </div>
                    </footer>
            </article>
            <article>
        <div className="image fit" style={{ margin: '0 0 0em 0'}}>
          <img src={four} alt="Official Guidelines" style={{width: '100px', height: '80px', display: 'block', margin: 'auto',}} /><br />
        </div>
        <header>
          <h3 style={{fontWeight: 'bold', textAlign: 'center'}}>Undertaking Form</h3>
        </header>
        <p style={{fontWeight: 'bold', textAlign:"center"}}>After reading and agreeing to the terms of service; all parties, including The Seeker/ their guardian, The Donor, The Consulting Doctor/ Healthcare Provider must sign the undertaking form</p>
        <p style={{fontWeight: 'bold',  textAlign:"center"}}>The duly filled and signed form shall be uploaded to <a href="mailto: xyz@gmail.com">xyz@gmail.com</a></p>
        <footer>
        <div className="align-center">
          <NavLink to={undertaking} className="button special" target="_blank">Download Undertaking Form</NavLink>
          </div>
        </footer>
      </article>
    </div>
  </div>
</section>
        </div>
    );
};

export default MoreThingsToKnow;