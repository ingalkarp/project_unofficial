
import React from 'react';

import {Link} from 'react-router-dom';

const admindashboard = () => {
    return (
        <div>
            {/* Banner */}
            <section id="banner">
                <h1 style={{fontWeight: 525}}>Curb The Virus<sup>©</sup> Digital Blood Bank</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Donate, Find Convalescent Blood Across The Nation</p>
            </section>

             {/* One */}
        <section id="one" className="wrapper">
            <div className="inner">
                <div className="flex flex-2">
                <article>
              <header>
                <h3 style={{fontWeight: 'bold'}}>Get Donor List<br /></h3>
              </header>
              <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Know about the blood Donors</p><br />
              <footer>
                <Link to= '/admin_donorslist' className="button special">
                    Show Donors List 
                </Link>
                
              </footer>
                </article>

                <article>
              <header>
                <h3 style={{fontWeight: 'bold'}}>Get Seekers List<br /></h3>
              </header>
              <p style={{fontWeight: 'bold', textAlign: 'justify'}}>Know about the Blood Seekers</p><br />
              <footer>
              <Link to= '/admin_seekerslist' className="button special">
                    Show Seekers List 
                </Link>
                
              </footer>
                </article>
    
            </div>
            </div> 
            </section> 


        </div>
    );
};

export default admindashboard;

