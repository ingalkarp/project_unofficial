import React, { Component } from 'react'
import SeekerService from '../services/SeekerService';
import { NavLink } from 'react-router-dom';
import undertaking from '../images/UNDERTAKING.pdf';

export default class ListDonorComponent extends Component {


	constructor(props) {
		super(props)
		this.state = this.initialState;
		this.logout = this.logout.bind(this);

	}

	initialState = {
		seeker: []
	}




	componentDidMount() {


		SeekerService.getDonorInfoAfterAcceptance(window.localStorage.getItem("donorEmail")).then((res) => {
			console.log(res.data.result);

			this.setState({ seeker: res.data.result });
			// console.log(window.localStorage.getItem("emailId"));
			// console.log(this.state.donor);
		});
	}

	logout() {
		alert("Goodbye, " + this.state.donor.firstName)
		window.localStorage.removeItem("emailId");
		console.log(this.setState(this.initialState));
		this.props.history.push('/');
	}

	back = (e) =>{
		e.preventDefault();
		// const stateName = this.state.stateName;
		this.props.history.push('/seekerdashboard');
	}


	render() {
		return (
			<div>
				<section id="banner">
                <h1 className="text-center" style={{ textTransform: 'uppercase', fontWeight: 525 }}>Hello, {this.state.seeker.firstName}</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Donate, Find Convalescent Blood Across The Nation</p>
            </section>
			<br />
				<h2 style={{fontWeight: 'bold', textAlign: 'center'}}>You Unlocked The Donor Details!</h2>
				<br />
				<div className="row">

					{/* <input type="text" name="email" onChange= {this.onChange}></input>
					<button onClick={this.searchByEmail}></button> */}
					{/* <h2 style={{fontWeight: 'bold', textAlign: 'center'}}>Hello, {this.state.seeker.firstName}</h2> */}
					<table className="table table-stripped table-bordered">
						<thead>
							<tr>
								
								<th>First Name</th>
								<th>Last Name</th>
								<th>Phone Number</th>
								<th>Age</th>
								<th>Email ID</th>
								<th>Blood Group</th>
								<th>State</th>
								<th>Last Symptom Date</th>
								
							</tr>
						</thead>
						<tbody>
							{
								// this.state.map(
								// 	donor =>
								<tr >
									
									<td> {this.state.seeker.firstName} </td>
									<td> {this.state.seeker.lastName} </td>
									<td> {this.state.seeker.phoneNumber} </td>
									<td> {this.state.seeker.age} </td>
									<td> {this.state.seeker.email} </td>
									<td> {this.state.seeker.bloodGroup} </td>
									<td> {this.state.seeker.stateName} </td>
									<td> {this.state.seeker.lastSymptomDate} </td>
									
								</tr>
								// )
							}
						</tbody>

					</table>
				</div>
				<br />
				<div className="editpage align-center">
				<button  type="submit" onClick={this.back.bind(this)} >Back</button>
				</div>
				<br />
					{/* <p style={{ textAlign: 'center'}}>Users MUST read and duly sign the completely filled  <NavLink to={undertaking} target="_blank">undertaking form</NavLink> at the time donors report at blood receiver's 
					location; BEFORE undergoing the transfusion process.</p> */}
				
			</div>
		)
	}
}
