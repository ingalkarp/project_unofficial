import React, { Component } from 'react'
import DonorService from '../services/DonorService'
import PersonService from '../services/PersonService';
import { NavLink } from 'react-router-dom';
import undertaking from '../images/UNDERTAKING.pdf';

export default class ListDonorComponent extends Component {


	constructor(props) {
		super(props)
		this.state = this.initialState;
		this.editUser = this.editUser.bind(this);
		this.logout = this.logout.bind(this);
		this.RequestsReceived = this.RequestsReceived.bind(this);
		this.DonorAcceptOrReject = this.DonorAcceptOrReject.bind(this);

	}

	initialState = {
		donor: [],
		seekers: []
	}




	componentDidMount() {

		// console.log(window.localStorage.getItem("emailId"));
		if (window.localStorage.getItem("role") === "DONOR") {
			DonorService.getDonor(window.localStorage.getItem("emailId")).then((res) => {
				// console.log(res.data.result);
				this.setState({ donor: res.data.result });
				// console.log(window.localStorage.getItem("emailId"));
				// console.log(this.state.donor);
			});	
			this.RequestsReceived();
		}
		// if (window.localStorage.getItem("role") === "SEEKER") {
		// 	console.log(window.localStorage.getItem("emailId"));
		// 	SeekerService.getSeeker(window.localStorage.getItem("emailId")).then((res) => {
		// 		// console.log(res.data.result);
		// 		this.setState({ donor: res.data.result });
		// 		// console.log(window.localStorage.getItem("emailId"));
		// 		// console.log(this.state.donor);
		// 	});
		// }

	}

	RequestsReceived() {
		DonorService.requestsReceived(window.localStorage.getItem("emailId")).then(
			res => {
				console.log(res.data)
				this.setState({ seekers: res.data.result });
				console.log("seekers", this.state.seekers);
			}
		);

	}

	DonorAcceptOrReject(seekerEmail,e){
		console.log(e.target.value)
		DonorService.donorAcceptOrReject(seekerEmail,window.localStorage.getItem("emailId"), e.target.value).then(
			res=>{
				console.log("Accepted");
				this.componentDidMount()
			}
		)
	}

	ShowSeekerDetails(requestStatus,seekerEmail){
		// console.log(e.target.value)
		if(requestStatus===2){
			window.localStorage.setItem("seekerEmail", seekerEmail);
			this.props.history.push("/seeker_details");
		}
		if(requestStatus===3){
			alert("you have rejected");
		}
	}

	editUser() {
		if (window.localStorage.getItem("role") ==="DONOR"){
			this.props.history.push('/edit_donor');
		}
		if (window.localStorage.getItem("role") ==="SEEKER"){
			this.props.history.push('/edit_seeker');
		}
	}
	logout() {
		alert("Goodbye, " + this.state.donor.firstName)
		window.localStorage.removeItem("emailId");
		console.log(this.setState(this.initialState));
		this.props.history.push('/');
	}

	deleteUser = (e) => {
		//e.preventDefault();
		// window.localStorage.removeItem("emailId");
		// console.log(this.setState(this.initialState));
		
		PersonService.deletePersonDetails(window.localStorage.getItem("emailId")).then(
			res => {
				alert("We feel sad to see you go.")
				window.localStorage.removeItem("emailId");
				// console.log(this.setState(this.initialState));
				this.props.history.push('/');
			}
		)

	}


	render() {
		return (
			<div>
				{/* Banner */}
				<section id="banner">
                <h1 className="text-center" style={{ textTransform: 'uppercase', fontWeight: 525 }}>Hello, {this.state.donor.firstName}</h1>
                <p style={{fontSize: 'x-large', fontWeight: 325}}>Donate, Find Convalescent Blood Across The Nation</p>
            </section>
			<div >
			<header>
				<br />
				<br />
				<h2 style={{fontWeight: 'bold', textAlign: 'center'}}>{this.state.donor.firstName} {this.state.donor.lastName}, {this.state.donor.age}
				({this.state.donor.bloodGroup}) <br /></h2>
			</header>
			</div>
			<br />
			<div>
			<table className="table table-stripped table-bordered">
						<thead>
							<tr>
								
							
								<th>First Name</th>
								<th>Last Name</th>
								<th>Phone Number</th>
								<th>Age</th>
								<th>Email ID</th>
								{/* <th>Password</th> */}
								<th>State Name</th>
								<th>Blood Group</th>
								<th>Last Date of Symptom</th>
							</tr>
						</thead>
						<tbody>
							{
								// this.state.map(
								// 	donor =>
								<tr >
									<td> {this.state.donor.firstName} </td>
									<td> {this.state.donor.lastName} </td>
									<td> {this.state.donor.phoneNumber} </td>
									<td> {this.state.donor.age} </td>
									<td> {this.state.donor.email} </td>
									{/* <td> {this.state.donor.password} </td> */}
									<td> {this.state.donor.stateName} </td>
									<td> {this.state.donor.bloodGroup} </td>
									<td> {this.state.donor.lastSymptomDate}</td>
								</tr>
							
								// )
							}
						</tbody>
						
					</table>
				</div>
					<br />
				
							<br />

							<div>
					<h2 style={{fontWeight: 'bold', textAlign: 'center'}}>You Have Received The Following Request(s):</h2>
					<div>
						<table>
							<thead>
								<tr>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Phone Number</th>
								<th>Age</th>
								<th>Email ID</th>
								{/* <th>Password</th> */}
								<th>State Name</th>
								<th>Blood Group</th>
								<th>Last Date of Symptom</th>
								<th>Request Status</th>
								</tr>
							</thead>
							<tbody>
							{
									this.state.seekers.map(
										seeker =>
											<tr key={seeker.donorId}>
												{console.log(seeker)}
												
												<td> {seeker.firstName} </td>
												<td> {seeker.lastName} </td>
												<td> {seeker.phoneNumber} </td>
												<td> {seeker.age} </td>
												<td> {seeker.emailId} </td>
												<td> {seeker.stateName} </td>
												<td> {seeker.bloodGroup} </td>
												<td> {seeker.lastSymptomDate} </td>
												 {seeker.requestStatus===1? <td>Requested</td>:null}
												 {seeker.requestStatus===2? <td>Accepted</td>: null}
												 {seeker.requestStatus===3? <td>Rejected</td>: null}
											
												<td><button value = "2" onClick = {(e)=>this.DonorAcceptOrReject(seeker.email,e)}>Accept</button></td>
												<td><button value = "3" onClick = {(e)=>this.DonorAcceptOrReject(seeker.email,e)}>Reject</button></td>
												<div>
												{seeker.requestStatus===2? <button onClick = {(e)=>this.ShowSeekerDetails(seeker.requestStatus,seeker.email)}>Show Details</button>:null}
												
												</div>
												
											</tr>
									)
								}
							</tbody>
						</table>
					</div>
				</div>
				<br />
				<div style={{ textAlign: 'center' }}>
					<button style={{ backgroundColor: '#7acdf1' }} onClick={this.logout}>Logout</button>{' '}
					<button style={{ backgroundColor: '#7acdf1' }} onClick={this.editUser}>Edit Details</button>{' '}
					{/* <button style={{ backgroundColor: '#7acdf1' }} onClick={this.addDonor}>Add Donor</button>{' '} */}
					<button style={{ backgroundColor: '#E14141' }} onClick={() => {if(window.confirm('Delete the item?')){this.deleteUser()};}}>Delete Profile</button>
					
				</div>
						<br />
					{/* <p style={{ textAlign: 'center'}}>Users MUST read and duly sign the completely filled  <NavLink to={undertaking} target="_blank">undertaking form</NavLink> at the time donors report at blood receiver's 
					location; BEFORE undergoing the transfusion process.</p> */}
				


			</div>
		)
	}
}
